# Backend API contract (implemented in backend/worker.js)

All requests send `X-Device-Id` (random UUID generated once per install).

## POST /v1/owner/unlock
Request: `{ "secret_code": "<your owner secret>" }`
Success 200: `{ "owner_token": "<signed token bound to device id>" }` (valid 7 days by default, `TOKEN_TTL_HOURS`)
Failure 401: `{ "error": "unauthorized" }` (delayed response to slow guessing)

## POST /v1/chat
Header: `Authorization: Bearer <owner_token>`
Request: `{ "messages": [ { "role": "user|assistant", "content": "..." } ] }` (last 20 used, last must be `user`)
Response: `{ "reply": "..." }`

## GET /v1/health
`{ "ok": true, "version": "0.2.0" }`

Notes: provider API key lives only in the Worker secrets. The app decodes responses as UTF-8.
`database/schema.sql` is optional and not used by this Worker (it keeps no server-side history).
