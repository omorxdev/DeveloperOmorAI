// Cloudflare Worker backend for DEVELOPER OMOR AI.
// Secrets (Settings → Variables and Secrets, type "Secret"):
//   ANTHROPIC_API_KEY  your Anthropic API key
//   OWNER_SECRET       your new long random owner code (NOT the one shown in chat)
//   TOKEN_SECRET       another long random string used to sign tokens
// Optional plain variables: MODEL (default claude-sonnet-5-5), TOKEN_TTL_HOURS (default 168)

const enc = new TextEncoder();
const b64u = (buf) =>
  btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const sha256Hex = async (s) => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

async function hmac(secret, data) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return b64u(await crypto.subtle.sign('HMAC', key, enc.encode(data)));
}

async function makeToken(env, deviceId) {
  const ttl = (Number(env.TOKEN_TTL_HOURS) || 168) * 3600 * 1000;
  const payload = b64u(enc.encode(JSON.stringify({ d: deviceId, e: Date.now() + ttl })));
  return `${payload}.${await hmac(env.TOKEN_SECRET, payload)}`;
}

async function verifyToken(env, token, deviceId) {
  const [p, sig] = (token || '').split('.');
  if (!p || !sig || !deviceId) return false;
  if (!safeEqual(sig, await hmac(env.TOKEN_SECRET, p))) return false;
  try {
    const j = JSON.parse(atob(p.replace(/-/g, '+').replace(/_/g, '/')));
    return j.d === deviceId && j.e > Date.now();
  } catch {
    return false;
  }
}

const SYSTEM = 'You are DEVELOPER OMOR AI, a helpful personal assistant. Reply in the same language the user writes in (Bangla or English). Be clear and concise.';

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const json = (o, s = 200) =>
      new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json; charset=utf-8' } });

    if (req.method === 'GET' && url.pathname === '/v1/health') return json({ ok: true, version: '0.2.0' });
    if (req.method !== 'POST') return json({ error: 'not_found' }, 404);
    if (!env.OWNER_SECRET || !env.TOKEN_SECRET || !env.ANTHROPIC_API_KEY) return json({ error: 'server_not_configured' }, 500);

    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: 'bad_request' }, 400);
    }
    const deviceId = req.headers.get('X-Device-Id') || '';

    if (url.pathname === '/v1/owner/unlock') {
      const ok = deviceId && safeEqual(await sha256Hex(String(body.secret_code || '')), await sha256Hex(env.OWNER_SECRET));
      if (!ok) {
        await new Promise((r) => setTimeout(r, 800)); // slow down guessing
        return json({ error: 'unauthorized' }, 401);
      }
      return json({ owner_token: await makeToken(env, deviceId) });
    }

    if (url.pathname === '/v1/chat') {
      const auth = (req.headers.get('Authorization') || '').replace(/^Bearer /, '');
      if (!(await verifyToken(env, auth, deviceId))) return json({ error: 'unauthorized' }, 401);

      const msgs = (Array.isArray(body.messages) ? body.messages : [])
        .slice(-20)
        .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 8000) }))
        .filter((m) => m.content);
      if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return json({ error: 'bad_request' }, 400);

      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
        body: JSON.stringify({ model: env.MODEL || 'claude-sonnet-5-5', max_tokens: 1024, system: SYSTEM, messages: msgs }),
      });
      if (!r.ok) return json({ error: 'upstream_error' }, 502);
      const d = await r.json();
      const reply = (d.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n');
      return json({ reply: reply || 'No reply returned.' });
    }
    return json({ error: 'not_found' }, 404);
  },
};
