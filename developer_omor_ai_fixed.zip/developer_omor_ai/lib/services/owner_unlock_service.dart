import 'dart:convert';
import 'package:http/http.dart' as http;
import 'settings_store.dart';

/// No login/register flow. Owner activation is a server-verified device unlock.
/// The secret is never stored in the app; only the short-lived token is.
class OwnerUnlockService {
  OwnerUnlockService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  /// Returns null on success, otherwise a message to show the user.
  Future<String?> unlock(String secretCode) async {
    final base = await SettingsStore.baseUrl();
    if (base.isEmpty) return 'আগে Backend URL সেট করুন।';
    if (secretCode.isEmpty) return 'কোড লিখুন।';
    try {
      final r = await _client
          .post(
            Uri.parse('$base/v1/owner/unlock'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'X-Device-Id': await SettingsStore.deviceId(),
            },
            body: jsonEncode({'secret_code': secretCode}),
          )
          .timeout(const Duration(seconds: 20));
      if (r.statusCode != 200) {
        return 'কোড সঠিক নয় বা সার্ভার সমস্যা (${r.statusCode})।';
      }
      final data = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      final token = data['owner_token'];
      if (token is! String || token.isEmpty) return 'সার্ভারের উত্তর ভুল।';
      await SettingsStore.setOwnerToken(token);
      return null;
    } catch (_) {
      return 'সার্ভারে সংযোগ হয়নি।';
    }
  }

  Future<bool> isUnlocked() async => (await SettingsStore.ownerToken()) != null;
  Future<void> lock() => SettingsStore.setOwnerToken(null);
}
