import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

/// Device-side settings. The backend URL is editable inside the app, so no
/// rebuild is needed when the server address changes.
class SettingsStore {
  static const _s = FlutterSecureStorage();
  static const _defaultUrl = String.fromEnvironment('API_BASE_URL');

  static Future<String> baseUrl() async {
    final v = await _s.read(key: 'api_base_url');
    return (v == null || v.isEmpty) ? _defaultUrl : v;
  }

  static Future<void> setBaseUrl(String url) async {
    var u = url.trim();
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    await _s.write(key: 'api_base_url', value: u);
  }

  static Future<String> deviceId() async {
    var id = await _s.read(key: 'device_id');
    if (id == null || id.isEmpty) {
      id = const Uuid().v4();
      await _s.write(key: 'device_id', value: id);
    }
    return id;
  }

  static Future<String?> ownerToken() => _s.read(key: 'owner_token');

  static Future<void> setOwnerToken(String? token) async {
    if (token == null) {
      await _s.delete(key: 'owner_token');
    } else {
      await _s.write(key: 'owner_token', value: token);
    }
  }
}
