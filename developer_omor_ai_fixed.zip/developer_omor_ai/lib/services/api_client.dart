import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'settings_store.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.unauthorized = false});
  final String message;
  final bool unauthorized;
  @override
  String toString() => message;
}

/// All provider keys stay on the server. The app only calls this API.
class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  /// [history] = [{'role': 'user'|'assistant', 'content': '...'}], last item is the new user message.
  Future<String> sendChat(List<Map<String, String>> history) async {
    final base = await SettingsStore.baseUrl();
    if (base.isEmpty) {
      throw ApiException('Settings → Backend URL সেট করা নেই।');
    }
    final token = await SettingsStore.ownerToken();
    if (token == null) {
      throw ApiException('আগে Settings → Owner Unlock করুন।', unauthorized: true);
    }
    final deviceId = await SettingsStore.deviceId();
    final http.Response r;
    try {
      r = await _client
          .post(
            Uri.parse('$base/v1/chat'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Authorization': 'Bearer $token',
              'X-Device-Id': deviceId,
            },
            body: jsonEncode({'messages': history}),
          )
          .timeout(const Duration(seconds: 60));
    } on TimeoutException {
      throw ApiException('সার্ভার সময়মতো উত্তর দেয়নি। আবার চেষ্টা করুন।');
    } catch (_) {
      throw ApiException('সার্ভারে সংযোগ হয়নি। ইন্টারনেট ও Backend URL দেখুন।');
    }
    if (r.statusCode == 401) {
      await SettingsStore.setOwnerToken(null);
      throw ApiException('সেশন শেষ। আবার Owner Unlock করুন।', unauthorized: true);
    }
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw ApiException('AI service error (${r.statusCode}).');
    }
    try {
      // decode bytes as UTF-8 explicitly, otherwise Bangla text can break
      final data = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      return data['reply'] as String? ?? 'No reply returned.';
    } catch (_) {
      throw ApiException('সার্ভারের উত্তর পড়া যায়নি।');
    }
  }
}
