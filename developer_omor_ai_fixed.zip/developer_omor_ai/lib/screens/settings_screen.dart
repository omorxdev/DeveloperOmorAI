import 'package:flutter/material.dart';
import '../services/owner_unlock_service.dart';
import '../services/settings_store.dart';
import 'app_shell.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final unlockService = OwnerUnlockService();
  String url = '';
  bool unlocked = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final u = await SettingsStore.baseUrl();
    final t = await unlockService.isUnlocked();
    if (!mounted) return;
    setState(() {
      url = u;
      unlocked = t;
    });
  }

  Future<String?> _ask(String title, {String? initial, bool secret = false}) {
    final ctl = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctl,
          obscureText: secret,
          autofocus: true,
          keyboardType: secret ? TextInputType.visiblePassword : TextInputType.url,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: const Text('OK')),
        ],
      ),
    );
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _setUrl() async {
    final v = await _ask('Backend URL (https://...)', initial: url);
    if (v == null) return;
    await SettingsStore.setBaseUrl(v);
    await _load();
  }

  Future<void> _toggleUnlock() async {
    if (unlocked) {
      await unlockService.lock();
      await _load();
      return;
    }
    final code = await _ask('Owner secret code', secret: true);
    if (code == null) return;
    final err = await unlockService.unlock(code);
    if (!mounted) return;
    _snack(err ?? 'Unlocked ✓');
    await _load();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const PageHeader(subtitle: 'CONFIGURATION'),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            _SettingTile(
              icon: Icons.cloud_outlined,
              title: 'Backend URL',
              subtitle: url.isEmpty ? 'Not set — tap to configure' : url,
              onTap: _setUrl,
            ),
            _SettingTile(
              icon: Icons.key_outlined,
              title: 'Owner Unlock',
              subtitle: unlocked ? 'Unlocked on this device — tap to lock' : 'Locked — tap to unlock with your secret code',
              onTap: _toggleUnlock,
            ),
            const _SettingTile(icon: Icons.smart_toy_outlined, title: 'AI Model', subtitle: 'Chosen on the backend (MODEL variable)'),
            const _SettingTile(icon: Icons.info_outline, title: 'About', subtitle: 'DEVELOPER OMOR AI • 0.2.0'),
          ]),
        ),
      ]);
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({required this.icon, required this.title, required this.subtitle, this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Card(
        color: const Color(0xFF141827),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon, color: const Color(0xFFB8AEFF)),
          title: Text(title),
          subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54)),
          trailing: onTap == null ? null : const Icon(Icons.chevron_right),
        ),
      );
}
