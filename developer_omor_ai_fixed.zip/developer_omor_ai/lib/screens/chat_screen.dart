import 'package:flutter/material.dart';
import '../services/api_client.dart';
import 'app_shell.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final scroll = ScrollController();
  final api = ApiClient();
  final messages = <({String text, bool mine})>[];
  bool loading = false;

  Future<void> send() async {
    final value = controller.text.trim();
    if (value.isEmpty || loading) return;
    setState(() {
      messages.add((text: value, mine: true));
      loading = true;
      controller.clear();
    });
    _toBottom();
    try {
      final all = [
        for (final m in messages) {'role': m.mine ? 'user' : 'assistant', 'content': m.text},
      ];
      final history = all.length > 20 ? all.sublist(all.length - 20) : all;
      final reply = await api.sendChat(history);
      if (!mounted) return;
      setState(() => messages.add((text: reply, mine: false)));
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        messages.removeLast();
        controller.text = value;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => loading = false);
    }
    _toBottom();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();
    scroll.dispose();
    super.dispose();
  }

  Widget _bubble(String text, bool mine) => Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          constraints: const BoxConstraints(maxWidth: 310),
          decoration: BoxDecoration(
            color: mine ? const Color(0xFF51469A) : const Color(0xFF171C2B),
            borderRadius: BorderRadius.circular(18),
          ),
          child: SelectableText(text),
        ),
      );

  @override
  Widget build(BuildContext context) => Column(children: [
        PageHeader(subtitle: loading ? 'THINKING' : 'ONLINE'),
        Expanded(
          child: messages.isEmpty
              ? Center(
                  child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: const Color(0xFF8B7CFF).withAlpha(64), blurRadius: 40)],
                        gradient: const RadialGradient(colors: [Color(0xFF51469A), Color(0xFF171B30)]),
                      ),
                      child: const Icon(Icons.auto_awesome, size: 42, color: Colors.white),
                    ),
                    const SizedBox(height: 24),
                    const Text('কীভাবে সাহায্য করতে পারি?',
                        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('প্রশ্ন করো, আইডিয়া দাও অথবা কোনো কাজের পরিকল্পনা করতে বলো।',
                        textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
                  ]),
                ))
              : ListView.builder(
                  controller: scroll,
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length + (loading ? 1 : 0),
                  itemBuilder: (context, i) {
                    if (i == messages.length) return _bubble('লিখছে...', false);
                    final m = messages[i];
                    return _bubble(m.text, m.mine);
                  }),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 5,
                decoration: const InputDecoration(hintText: 'Omor AI-কে কিছু জিজ্ঞেস করো...'),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: loading ? null : send, icon: const Icon(Icons.arrow_upward)),
          ]),
        ),
      ]);
}
