import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../services/api_client.dart';
import 'app_shell.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});
  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final stt = SpeechToText();
  final tts = FlutterTts();
  final api = ApiClient();
  final history = <Map<String, String>>[];
  bool listening = false;
  bool busy = false;
  String locale = 'bn_BD';
  String status = 'Omor AI Voice';
  String heard = '';
  String reply = '';

  Future<void> toggle() async {
    if (busy) return;
    if (listening) {
      await stt.stop();
      return;
    }
    await tts.stop();
    final ok = await stt.initialize(
      onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && mounted) setState(() => listening = false);
      },
      onError: (e) {
        if (mounted) {
          setState(() {
            listening = false;
            status = 'মাইক্রোফোন ত্রুটি: ${e.errorMsg}';
          });
        }
      },
    );
    if (!ok) {
      if (mounted) setState(() => status = 'মাইক্রোফোন/Speech recognition পাওয়া যায়নি। Permission দিন।');
      return;
    }
    if (!mounted) return;
    setState(() {
      listening = true;
      heard = '';
      status = 'শুনছি...';
    });
    await stt.listen(
      localeId: locale,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      onResult: (r) {
        if (!mounted) return;
        setState(() => heard = r.recognizedWords);
        if (r.finalResult) _ask(r.recognizedWords);
      },
    );
  }

  Future<void> _ask(String text) async {
    final q = text.trim();
    if (q.isEmpty || busy) return;
    busy = true;
    history.add({'role': 'user', 'content': q});
    if (mounted) setState(() => status = 'ভাবছি...');
    try {
      final all = history.length > 20 ? history.sublist(history.length - 20) : history;
      final answer = await api.sendChat(all);
      history.add({'role': 'assistant', 'content': answer});
      if (!mounted) return;
      setState(() {
        reply = answer;
        status = 'Omor AI Voice';
      });
      await tts.setLanguage(locale.replaceAll('_', '-'));
      await tts.speak(answer);
    } on ApiException catch (e) {
      history.removeLast();
      if (mounted) setState(() => status = e.message);
    } finally {
      busy = false;
    }
  }

  @override
  void dispose() {
    stt.cancel();
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const PageHeader(subtitle: 'VOICE ASSISTANT'),
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(colors: [Color(0xFF5E50B8), Color(0xFF151A2B)]),
                    boxShadow: [
                      BoxShadow(color: const Color(0xFF8B7CFF).withAlpha(listening ? 120 : 60), blurRadius: 55, spreadRadius: 8),
                    ],
                  ),
                  child: const Icon(Icons.graphic_eq, size: 76, color: Colors.white),
                ),
                const SizedBox(height: 24),
                Text(status, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                if (heard.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(heard, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                ],
                if (reply.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(reply, textAlign: TextAlign.center, maxLines: 8, overflow: TextOverflow.ellipsis),
                ],
              ]),
            ),
          ),
        ),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'bn_BD', label: Text('বাংলা')),
            ButtonSegment(value: 'en_US', label: Text('English')),
          ],
          selected: {locale},
          onSelectionChanged: listening ? null : (s) => setState(() => locale = s.first),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 16, 0, 32),
          child: FilledButton.icon(
            onPressed: toggle,
            icon: Icon(listening ? Icons.stop : Icons.mic),
            label: Text(listening ? 'Stop listening' : 'Start voice chat'),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18)),
          ),
        ),
      ]);
}
