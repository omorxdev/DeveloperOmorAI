# DEVELOPER OMOR AI (Native Kotlin)

এটা একটি সম্পূর্ণ native Android অ্যাপ (একটাই MainActivity.kt)।  
অনেক AI প্রদানকারী সাপোর্ট করে (Gemini, Groq, Cerebras, OpenRouter, Claude, Custom, নিজের Backend)।

## ফিচার
- মাল্টি-ল্যাঙ্গুয়েজ চ্যাট (বাংলাসহ ২০+ ভয়েস ল্যাঙ্গুয়েজ)
- ভয়েস ইনপুট + TTS
- স্ক্রিনশট/ছবি পাঠিয়ে এরর অ্যানালাইসিস
- কোড ফাইলের এরর ফিক্স
- HTML গেম জেনারেট + ইন-অ্যাপ রান
- ভিডিও ট্রিম (রি-এনকোড ছাড়া)
- Premium রিডিম (লোকাল)
- নিজের Cloudflare Worker backend সাপোর্ট

## কীভাবে APK বানাবেন

### উপায় ১: Android Studio (সবচেয়ে সহজ)
1. Android Studio ইন্সটল করুন (PC/Mac)।
2. এই ফোল্ডারটি **Open** করুন (File → Open → DeveloperOmorAI ফোল্ডার)।
3. প্রথমবার Gradle sync হতে দিবেন।
4. উপরের টুলবারে **Build → Build Bundle(s) / APK(s) → Build APK(s)** চাপুন।
5. Build শেষ হলে `app/build/outputs/apk/release/app-release-unsigned.apk` পাবেন।
6. সাইন করতে চাইলে Build → Generate Signed Bundle / APK ব্যবহার করুন।

### উপায় ২: GitHub Actions দিয়ে
1. এই পুরো প্রজেক্ট GitHub-এ নতুন রিপোজিটরিতে আপলোড করুন।
2. Actions ট্যাব থেকে workflow চালান (যদি workflow যোগ করেন)।
3. Artifact থেকে APK ডাউনলোড করুন।

## প্রথমবার সেটআপ
1. অ্যাপ খুলুন → **AI Key** চাপুন।
2. কোনো ফ্রি প্রদানকারী বেছে নিন (Gemini / Groq / OpenRouter)।
3. তাদের সাইট থেকে API Key নিয়ে দিন।
4. Model নাম ঠিক আছে কিনা দেখুন।
5. চ্যাট শুরু করুন।

## Premium
`Premium` বোতামে রিডিম কোড দিলে Pro ফিচার আনলক হয় (Tools, HTML Run ইত্যাদি)।

## নোট
- API Key আপনার ডিভাইসে SharedPreferences-এ থাকে। পাবলিক অ্যাপে কখনো রিয়েল কী এমবেড করবেন না।
- Backend (Cloudflare Worker) ব্যবহার করতে চাইলে `backend/worker.js` (Flutter ভার্সনে ছিল) থেকে আইডিয়া নিতে পারেন।
- আইকন এখনো সিস্টেম আইকন। Android Studio → Image Asset দিয়ে নিজের আইকন বানিয়ে নিন।

Version: 1.1.0
