package com.omor.developeromorai

import android.Manifest
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

class AiError(message: String) : Exception(message)

class Provider(val id: String, val label: String, val kind: String, val base: String, val defModel: String)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private val SYSTEM = "You are DEVELOPER OMOR AI, a helpful assistant that understands and replies in 100+ languages. " +
        "Always reply in the same language the user writes in. You fix errors in code, files and screenshots " +
        "(explain the cause briefly, then give the full corrected code in a fenced code block), write small programs, " +
        "and build games as ONE self-contained HTML file inside a single ```html code block with touch controls for phones."

    // sha-256 of the premium redeem code (the plain code is not stored in the app)
    private val PRO_HASH = "57384495167b936ee691db83223b5809f15b4440af552a4121e1c1f86b7ede44"

    private val providers = listOf(
        Provider("gemini", "Google Gemini (ফ্রি)", "gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.0-flash"),
        Provider("groq", "Groq (ফ্রি)", "openai", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
        Provider("cerebras", "Cerebras (ফ্রি)", "openai", "https://api.cerebras.ai/v1", "llama3.1-8b"),
        Provider("openrouter", "OpenRouter (ফ্রি মডেল)", "openai", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free"),
        Provider("anthropic", "Anthropic Claude (পেইড)", "anthropic", "https://api.anthropic.com/v1", "claude-3-5-sonnet-latest"),
        Provider("custom", "অন্য যেকোনো OpenAI-compatible API", "openai", "", ""),
        Provider("backend", "আমার নিজের Backend (Worker)", "backend", "", "")
    )

    private val langs = listOf(
        Pair("বাংলা", "bn-BD"), Pair("English", "en-US"), Pair("हिन्दी", "hi-IN"), Pair("اردو", "ur-PK"),
        Pair("العربية", "ar-SA"), Pair("Español", "es-ES"), Pair("Français", "fr-FR"), Pair("Deutsch", "de-DE"),
        Pair("Português", "pt-BR"), Pair("Русский", "ru-RU"), Pair("中文", "zh-CN"), Pair("日本語", "ja-JP"),
        Pair("한국어", "ko-KR"), Pair("Türkçe", "tr-TR"), Pair("Bahasa Indonesia", "id-ID"), Pair("Italiano", "it-IT"),
        Pair("தமிழ்", "ta-IN"), Pair("Bahasa Melayu", "ms-MY"), Pair("ภาษาไทย", "th-TH"), Pair("Tiếng Việt", "vi-VN")
    )

    private val prefs by lazy { getSharedPreferences("omor", Context.MODE_PRIVATE) }
    private val history = JSONArray()
    private lateinit var titleView: TextView
    private lateinit var chatBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var sendBtn: Button
    private lateinit var langBtn: Button
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var voiceTag = "bn-BD"
    private var speakReplies = false
    private var pendingSave: String? = null
    private var pendingSaveHtml = false
    private var pendingVideo: Uri? = null

    private val bg = Color.parseColor("#090B14")
    private val mineColor = Color.parseColor("#51469A")
    private val botColor = Color.parseColor("#171C2B")

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun isPro() = prefs.getBoolean("pro", false)

    private fun deviceId(): String {
        var id = prefs.getString("device_id", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    // ---------- UI ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(root)

        titleView = TextView(this)
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 18f
        titleView.setTypeface(null, Typeface.BOLD)
        titleView.setPadding(dp(16), dp(14), dp(16), dp(4))
        root.addView(titleView)
        updateTitle()

        val bar1 = LinearLayout(this)
        bar1.orientation = LinearLayout.HORIZONTAL
        bar1.setPadding(dp(8), 0, dp(8), 0)
        val keyBtn = Button(this)
        keyBtn.text = "AI Key"
        val permBtn = Button(this)
        permBtn.text = "Permissions"
        langBtn = Button(this)
        langBtn.text = "বাংলা"
        for (b in listOf(keyBtn, permBtn, langBtn)) {
            b.textSize = 12f
            bar1.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(bar1)

        val bar2 = LinearLayout(this)
        bar2.orientation = LinearLayout.HORIZONTAL
        bar2.setPadding(dp(8), 0, dp(8), 0)
        val toolsBtn = Button(this)
        toolsBtn.text = "Tools"
        val premBtn = Button(this)
        premBtn.text = "Premium"
        for (b in listOf(toolsBtn, premBtn)) {
            b.textSize = 12f
            bar2.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(bar2)

        status = TextView(this)
        status.setTextColor(Color.parseColor("#9AA0B5"))
        status.setPadding(dp(16), dp(4), dp(16), dp(4))
        status.text = "শুরু করতে 'AI Key' চাপুন ও একটা প্রদানকারী বেছে নিন।"
        root.addView(status)

        scroll = ScrollView(this)
        chatBox = LinearLayout(this)
        chatBox.orientation = LinearLayout.VERTICAL
        chatBox.setPadding(dp(12), dp(8), dp(12), dp(8))
        scroll.addView(chatBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(dp(8), dp(6), dp(8), dp(10))
        val micBtn = Button(this)
        micBtn.text = "🎤"
        input = EditText(this)
        input.hint = "Omor AI-কে কিছু জিজ্ঞেস করো..."
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        input.maxLines = 4
        sendBtn = Button(this)
        sendBtn.text = "➤"
        bottom.addView(micBtn)
        bottom.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(sendBtn)
        root.addView(bottom)

        keyBtn.setOnClickListener { chooseProvider() }
        permBtn.setOnClickListener { permissionsDialog() }
        langBtn.setOnClickListener { chooseLanguage() }
        toolsBtn.setOnClickListener { toolsDialog() }
        premBtn.setOnClickListener { premiumDialog() }
        sendBtn.setOnClickListener {
            speakReplies = false
            send(input.text.toString())
        }
        micBtn.setOnClickListener { listen() }
    }

    private fun updateTitle() {
        titleView.text = if (isPro()) "DEVELOPER OMOR AI  ⭐ PRO" else "DEVELOPER OMOR AI"
    }

    private fun addBubble(text: String, mine: Boolean) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        val shape = GradientDrawable()
        shape.cornerRadius = dp(16).toFloat()
        shape.setColor(if (mine) mineColor else botColor)
        tv.background = shape
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.bottomMargin = dp(8)
        chatBox.addView(tv, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private val codeRe = Regex("```([a-zA-Z0-9]*)[ \\t]*\\n([\\s\\S]*?)```")

    private fun addCodeActions(reply: String) {
        val m = codeRe.find(reply) ?: return
        val lang = m.groupValues[1].lowercase()
        val code = m.groupValues[2]
        val isHtml = lang == "html" || code.contains("<html", true) || code.contains("<!doctype", true)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.textSize = 11f
            b.setOnClickListener { onClick() }
            row.addView(b)
        }
        btn("Copy") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("code", code))
            toast("কপি হয়েছে")
        }
        btn("Save") { saveCode(code, isHtml) }
        if (isHtml) btn("▶ Run") { if (requirePro()) runHtml(code) }
        chatBox.addView(row)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun ask(title: String, secret: Boolean, initial: String = "", onOk: (String) -> Unit) {
        val e = EditText(this)
        e.setText(initial)
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(e)
            .setPositiveButton("OK") { _, _ -> onOk(e.text.toString().trim()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Premium ----------
    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun requirePro(): Boolean {
        if (isPro()) return true
        toast("এটা Pro ফিচার। 'Premium' বোতামে রিডিম কোড দিন।")
        return false
    }

    private fun premiumDialog() {
        if (isPro()) {
            toast("Pro প্ল্যান সক্রিয় আছে ⭐ — সব ফিচার আনলক")
            return
        }
        ask("Premium — রিডিম কোড দিন", true) { code ->
            if (sha256(code) == PRO_HASH) {
                prefs.edit().putBoolean("pro", true).apply()
                updateTitle()
                toast("অভিনন্দন! Pro প্ল্যান চালু ⭐ সব ফিচার আনলক হয়েছে")
            } else toast("কোডটি সঠিক নয়")
        }
    }

    // ---------- Language ----------
    private fun chooseLanguage() {
        AlertDialog.Builder(this)
            .setTitle("ভয়েসের ভাষা (লেখায় AI যেকোনো ভাষা বোঝে)")
            .setItems(langs.map { it.first }.toTypedArray()) { _, i ->
                voiceTag = langs[i].second
                langBtn.text = langs[i].first
            }
            .show()
    }

    // ---------- Tools ----------
    private fun toolsDialog() {
        val items = arrayOf(
            "📎 ফাইল বেছে এরর ঠিক করুন",
            "🖼 স্ক্রিনশট/ছবি পাঠিয়ে সমস্যা জিজ্ঞেস করুন",
            "🎮 গেম বানান",
            "✂ ভিডিও ট্রিম (কাটুন)",
            "🗑 ছবি মুছুন (নিশ্চিত করে)"
        )
        AlertDialog.Builder(this)
            .setTitle(if (isPro()) "Tools ⭐" else "Tools (Pro দরকার)")
            .setItems(items) { _, i ->
                if (!requirePro()) return@setItems
                when (i) {
                    0 -> {
                        val it = Intent(Intent.ACTION_OPEN_DOCUMENT)
                        it.addCategory(Intent.CATEGORY_OPENABLE)
                        it.type = "*/*"
                        startActivityForResult(it, 11)
                    }
                    1 -> startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 12)
                    2 -> ask("কী গেম বানাতে চান?") { idea ->
                        if (idea.isNotEmpty()) send("একটা সম্পূর্ণ single-file HTML/JS/CSS গেম বানাও: $idea। ফোনের টাচ কন্ট্রোল সহ, একটাই ```html কোড ব্লকে দাও।")
                    }
                    3 -> startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI), 15)
                    else -> startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 14)
                }
            }
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data
        when (requestCode) {
            11 -> if (uri != null) fixFile(uri)
            12 -> if (uri != null) sendImage(uri)
            13 -> if (uri != null) writeSaved(uri)
            14 -> if (uri != null) deleteImage(uri)
            15 -> if (uri != null) askTrim(uri)
            16 -> toast("ছবি মুছে ফেলা হয়েছে ✓")
        }
    }

    private fun fixFile(uri: Uri) {
        thread {
            try {
                var name = "file"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0) name = c.getString(i)
                    }
                }
                val buf = ByteArray(100000)
                var n = 0
                contentResolver.openInputStream(uri)?.use { s ->
                    while (n < buf.size) {
                        val r = s.read(buf, n, buf.size - n)
                        if (r < 0) break
                        n += r
                    }
                }
                val text = String(buf, 0, n, Charsets.UTF_8)
                if (text.contains('\u0000')) {
                    runOnUiThread { toast("এটা টেক্সট/কোড ফাইল নয়") }
                    return@thread
                }
                val msg = "এই ফাইলের (নাম: $name) সব এরর খুঁজে ঠিক করো। কারণ সংক্ষেপে বলো, তারপর পুরো ঠিক করা কোড দাও।\n\n```\n$text\n```"
                runOnUiThread { send(msg, "📎 $name পাঠানো হলো — এরর ঠিক করতে বলা হয়েছে", null) }
            } catch (e: Exception) {
                runOnUiThread { toast("ফাইল পড়া যায়নি") }
            }
        }
    }

    private fun sendImage(uri: Uri) {
        thread {
            val b64 = try { loadImageB64(uri) } catch (e: Exception) { null }
            runOnUiThread {
                if (b64 == null) {
                    toast("ছবি পড়া যায়নি")
                } else {
                    val q = input.text.toString().trim()
                    val msg = if (q.isNotEmpty()) q else "এই স্ক্রিনে কী সমস্যা বা এরর আছে? কারণ ও সমাধান ধাপে ধাপে বলো।"
                    input.setText("")
                    send(msg, "🖼 ছবি পাঠানো হলো\n$msg", b64)
                }
            }
        }
    }

    private fun loadImageB64(uri: Uri): String? {
        val o1 = BitmapFactory.Options()
        o1.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o1) }
        var s = 1
        while (o1.outWidth / s > 1600 || o1.outHeight / s > 1600) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun saveCode(code: String, html: Boolean) {
        pendingSave = code
        pendingSaveHtml = html
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (html) "text/html" else "text/plain"
        i.putExtra(Intent.EXTRA_TITLE, if (html) "omor_game.html" else "omor_code.txt")
        startActivityForResult(i, 13)
    }

    private fun writeSaved(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write((pendingSave ?: "").toByteArray(Charsets.UTF_8)) }
            toast("সেভ হয়েছে ✓")
        } catch (e: Exception) {
            toast("সেভ করা যায়নি")
        }
    }

    private fun runHtml(html: String) {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.blockNetworkLoads = true
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(wv)
        d.show()
        toast("বন্ধ করতে Back চাপুন")
    }

    private fun deleteImage(uri: Uri) {
        if (Build.VERSION.SDK_INT < 30) {
            toast("এই ফিচার Android 11 বা তার পরে কাজ করে।")
            return
        }
        try {
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
            startIntentSenderForResult(pi.intentSender, 16, null, 0, 0, 0)
        } catch (e: Exception) {
            toast("এই ছবি অ্যাপ থেকে মোছা গেল না। গ্যালারি থেকে মুছুন।")
        }
    }

    private fun askTrim(uri: Uri) {
        pendingVideo = uri
        ask("শুরু (সেকেন্ড, যেমন 0)") { s ->
            ask("শেষ (সেকেন্ড, যেমন 10)") { e ->
                val a = s.toDoubleOrNull()
                val b = e.toDoubleOrNull()
                if (a == null || b == null || b <= a || a < 0) toast("সংখ্যা ঠিকমতো দিন (শেষ > শুরু)")
                else trimVideo(uri, a, b)
            }
        }
    }

    // Trims without re-encoding. Cut starts at the nearest keyframe before the start time.
    private fun trimVideo(src: Uri, startS: Double, endS: Double) {
        toast("ট্রিম হচ্ছে...")
        thread {
            var pfd: ParcelFileDescriptor? = null
            var outUri: Uri? = null
            val ex = MediaExtractor()
            try {
                contentResolver.openFileDescriptor(src, "r")!!.use { ex.setDataSource(it.fileDescriptor) }
                val name = "omor_trim_${System.currentTimeMillis()}.mp4"
                val muxer: MediaMuxer
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues()
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/OmorAI")
                    outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                    pfd = contentResolver.openFileDescriptor(outUri!!, "rw")
                    muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                } else {
                    val f = java.io.File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), name)
                    muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                }
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(this, src)
                val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                mmr.release()
                muxer.setOrientationHint(rot)

                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString("mime") ?: ""
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        ex.selectTrack(i)
                        map[i] = muxer.addTrack(f)
                    }
                }
                if (map.isEmpty()) throw Exception("no tracks")
                muxer.start()
                ex.seekTo((startS * 1_000_000).toLong(), MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(4 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                var base = -1L
                val endUs = (endS * 1_000_000).toLong()
                while (true) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val t = ex.sampleTime
                    if (t > endUs) break
                    if (base < 0) base = t
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = maxOf(0L, t - base)
                    info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(map[ex.sampleTrackIndex]!!, buf, info)
                    ex.advance()
                }
                muxer.stop()
                muxer.release()
                runOnUiThread { toast("ট্রিম হয়েছে ✓ — Movies/OmorAI ফোল্ডারে সেভ") }
            } catch (e: Exception) {
                try { outUri?.let { contentResolver.delete(it, null, null) } } catch (x: Exception) { }
                runOnUiThread { toast("ভিডিও ট্রিম করা যায়নি") }
            } finally {
                ex.release()
                try { pfd?.close() } catch (x: Exception) { }
            }
        }
    }

    // ---------- Provider setup ----------
    private fun currentProvider(): Provider? {
        val id = prefs.getString("provider", null) ?: return null
        return providers.firstOrNull { it.id == id }
    }

    private fun chooseProvider() {
        AlertDialog.Builder(this)
            .setTitle("AI প্রদানকারী বেছে নিন")
            .setItems(providers.map { it.label }.toTypedArray()) { _, i -> configure(providers[i]) }
            .show()
    }

    private fun configure(p: Provider) {
        prefs.edit().putString("provider", p.id).apply()
        when {
            p.kind == "backend" ->
                ask("Backend URL (https://...)", false, prefs.getString("url", "") ?: "") { u ->
                    val url = u.trimEnd('/')
                    if (!url.startsWith("https://")) {
                        toast("URL অবশ্যই https:// দিয়ে শুরু হতে হবে")
                    } else {
                        prefs.edit().putString("url", url).apply()
                        ask("Owner secret code", true) { code -> unlock(code) }
                    }
                }
            p.id == "custom" ->
                ask("Base URL (যেমন https://api.example.com/v1)", false, prefs.getString("base_custom", "") ?: "") { b ->
                    prefs.edit().putString("base_custom", b.trimEnd('/')).apply()
                    askKey(p)
                }
            else -> askKey(p)
        }
    }

    private fun askKey(p: Provider) {
        ask("${p.label} — API key (খালি রাখলে আগেরটাই থাকবে)", true) { k ->
            if (k.isNotEmpty()) prefs.edit().putString("key_${p.id}", k).apply()
            val saved = prefs.getString("model_${p.id}", "") ?: ""
            ask("Model নাম (ছবি পাঠাতে ভিশন-সাপোর্টেড মডেল লাগবে)", false, if (saved.isNotEmpty()) saved else p.defModel) { m ->
                prefs.edit().putString("model_${p.id}", m).apply()
                status.text = "প্রদানকারী: ${p.label}"
                toast("সংরক্ষিত ✓ — এখন চ্যাট করতে পারেন")
            }
        }
    }

    // ---------- Network ----------
    private fun http(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun fail(c: Int, r: String): Nothing {
        val detail = try {
            val e = JSONObject(r).opt("error")
            when (e) {
                is JSONObject -> e.optString("message")
                is String -> e
                else -> ""
            }
        } catch (x: Exception) {
            ""
        }
        val msg = when (c) {
            401, 403 -> "API key ভুল বা অনুমতি নেই ($c)"
            429 -> "ফ্রি সীমা শেষ। একটু পরে চেষ্টা করুন (429)"
            404 -> "মডেল বা URL পাওয়া যায়নি। Model নাম দেখুন (404)"
            else -> "সার্ভার ত্রুটি ($c)"
        }
        throw AiError(if (detail.isNotEmpty()) "$msg: ${detail.take(120)}" else msg)
    }

    private fun turns(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (i in maxOf(0, history.length() - 12) until history.length()) {
            val o = history.getJSONObject(i)
            out.add(Pair(o.getString("role"), o.getString("content")))
        }
        return out
    }

    private fun callAi(h: List<Pair<String, String>>, img: String?): String {
        val p = currentProvider() ?: throw AiError("আগে 'AI Key' বোতামে একটা প্রদানকারী বেছে নিন।")
        if (p.kind == "backend") {
            if (img != null) throw AiError("Backend-এ ছবি পাঠানো যায় না। Gemini বা Claude বেছে নিন।")
            return callBackend(h)
        }
        val key = prefs.getString("key_${p.id}", "") ?: ""
        if (key.isEmpty()) throw AiError("${p.label}-এর API key দিন।")
        val saved = prefs.getString("model_${p.id}", "") ?: ""
        val model = if (saved.isNotEmpty()) saved else p.defModel
        val base = if (p.id == "custom") prefs.getString("base_custom", "") ?: "" else p.base
        if (base.isEmpty() || model.isEmpty()) throw AiError("Base URL ও Model নাম দিন।")
        return when (p.kind) {
            "gemini" -> callGemini(base, key, model, h, img)
            "anthropic" -> callAnthropic(base, key, model, h, img)
            else -> callOpenAi(base, key, model, h, img)
        }
    }

    private fun isLastUser(i: Int, role: String, size: Int, img: String?) = img != null && i == size - 1 && role == "user"

    private fun callOpenAi(base: String, key: String, model: String, h: List<Pair<String, String>>, img: String?): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", SYSTEM))
        for ((i, m) in h.withIndex()) {
            val (role, text) = m
            if (isLastUser(i, role, h.size, img)) {
                val parts = JSONArray()
                parts.put(JSONObject().put("type", "text").put("text", text))
                parts.put(JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$img")))
                msgs.put(JSONObject().put("role", role).put("content", parts))
            } else msgs.put(JSONObject().put("role", role).put("content", text))
        }
        val (c, r) = http("$base/chat/completions", mapOf("Authorization" to "Bearer $key"),
            JSONObject().put("model", model).put("messages", msgs))
        if (c !in 200..299) fail(c, r)
        val choices = JSONObject(r).optJSONArray("choices")
        return choices?.getJSONObject(0)?.getJSONObject("message")?.optString("content", "") ?: ""
    }

    private fun callGemini(base: String, key: String, model: String, h: List<Pair<String, String>>, img: String?): String {
        val contents = JSONArray()
        for ((i, m) in h.withIndex()) {
            val (role, text) = m
            val parts = JSONArray()
            parts.put(JSONObject().put("text", text))
            if (isLastUser(i, role, h.size, img)) {
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img)))
            }
            contents.put(JSONObject().put("role", if (role == "assistant") "model" else "user").put("parts", parts))
        }
        val body = JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
        val (c, r) = http("$base/models/$model:generateContent", mapOf("x-goog-api-key" to key), body)
        if (c !in 200..299) fail(c, r)
        val parts = JSONObject(r).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun callAnthropic(base: String, key: String, model: String, h: List<Pair<String, String>>, img: String?): String {
        val msgs = JSONArray()
        for ((i, m) in h.withIndex()) {
            val (role, text) = m
            if (isLastUser(i, role, h.size, img)) {
                val parts = JSONArray()
                parts.put(JSONObject().put("type", "image").put("source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)))
                parts.put(JSONObject().put("type", "text").put("text", text))
                msgs.put(JSONObject().put("role", role).put("content", parts))
            } else msgs.put(JSONObject().put("role", role).put("content", text))
        }
        val (c, r) = http("$base/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            JSONObject().put("model", model).put("max_tokens", 4096).put("system", SYSTEM).put("messages", msgs))
        if (c !in 200..299) fail(c, r)
        val arr = JSONObject(r).optJSONArray("content")
        val sb = StringBuilder()
        if (arr != null) for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text", ""))
        }
        return sb.toString()
    }

    private fun callBackend(h: List<Pair<String, String>>): String {
        val base = prefs.getString("url", "") ?: ""
        val token = prefs.getString("token", "") ?: ""
        if (base.isEmpty() || token.isEmpty()) throw AiError("Backend URL ও Owner Unlock দরকার ('AI Key' থেকে)।")
        val msgs = JSONArray()
        for ((role, text) in h) msgs.put(JSONObject().put("role", role).put("content", text))
        val (c, r) = http("$base/v1/chat", mapOf("Authorization" to "Bearer $token", "X-Device-Id" to deviceId()),
            JSONObject().put("messages", msgs))
        if (c == 401) {
            prefs.edit().remove("token").apply()
            throw AiError("সেশন শেষ। 'AI Key' থেকে আবার Unlock করুন।")
        }
        if (c !in 200..299) fail(c, r)
        return JSONObject(r).optString("reply", "")
    }

    private fun unlock(code: String) {
        if (code.isEmpty()) { toast("কোড লিখুন"); return }
        thread {
            val msg = try {
                val base = prefs.getString("url", "") ?: ""
                val (c, r) = http("$base/v1/owner/unlock", mapOf("X-Device-Id" to deviceId()),
                    JSONObject().put("secret_code", code))
                if (c == 200) {
                    prefs.edit().putString("token", JSONObject(r).optString("owner_token")).apply()
                    "Unlocked ✓ — এখন চ্যাট করতে পারেন"
                } else "কোড সঠিক নয় ($c)"
            } catch (e: Exception) {
                "সার্ভারে সংযোগ হয়নি।"
            }
            runOnUiThread { toast(msg) }
        }
    }

    // display = what to show in the bubble (defaults to the text itself); img = base64 JPEG for this turn only
    private fun send(text: String, display: String? = null, img: String? = null) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (currentProvider() == null) { toast("আগে 'AI Key' চাপুন"); return }

        addBubble(display ?: t, true)
        if (display == null) input.setText("")
        history.put(JSONObject().put("role", "user").put("content", t))
        sendBtn.isEnabled = false
        status.text = "ভাবছি..."

        thread {
            var reply: String? = null
            var err: String? = null
            try {
                val r = callAi(turns(), img)
                reply = if (r.isEmpty()) "(খালি উত্তর এসেছে)" else r
            } catch (e: AiError) {
                err = e.message
            } catch (e: Exception) {
                err = "সংযোগ হয়নি। ইন্টারনেট ও URL দেখুন।"
            }
            runOnUiThread {
                sendBtn.isEnabled = true
                status.text = currentProvider()?.let { "প্রদানকারী: ${it.label}" } ?: ""
                if (reply != null) {
                    history.put(JSONObject().put("role", "assistant").put("content", reply))
                    addBubble(reply, false)
                    addCodeActions(reply)
                    if (speakReplies) speak(reply)
                } else {
                    history.remove(history.length() - 1)
                    if (display == null) input.setText(t)
                    toast(err ?: "ত্রুটি")
                }
            }
        }
    }

    // ---------- Permissions ----------
    private val micPerms get() = arrayOf(Manifest.permission.RECORD_AUDIO)
    private val notifPerms get() =
        if (Build.VERSION.SDK_INT >= 33) arrayOf("android.permission.POST_NOTIFICATIONS") else emptyArray()
    private val storagePerms get() =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf("android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_AUDIO")
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun granted(p: Array<String>) = p.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun mark(p: Array<String>) = if (p.isEmpty()) "✓ (দরকার নেই)" else if (granted(p)) "✓" else "✗"

    private fun permissionsDialog() {
        val items = arrayOf(
            "মাইক্রোফোন  ${mark(micPerms)}",
            "নোটিফিকেশন  ${mark(notifPerms)}",
            "স্টোরেজ / মিডিয়া  ${mark(storagePerms)}",
            "Accessibility সেটিংস খুলুন",
            "অ্যাপের সব Permission (ফোন সেটিংস)"
        )
        AlertDialog.Builder(this)
            .setTitle("Permissions")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> requestGroup(micPerms, 2)
                    1 -> requestGroup(notifPerms, 3)
                    2 -> requestGroup(storagePerms, 4)
                    3 -> {
                        toast("অ্যাপে এখনো Accessibility Service নেই, তাই তালিকায় আসবে না।")
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    else -> openAppSettings()
                }
            }
            .show()
    }

    private fun requestGroup(p: Array<String>, code: Int) {
        if (p.isEmpty() || granted(p)) {
            toast("এটা আগেই দেওয়া আছে ✓")
            return
        }
        requestPermissions(p, code)
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (requestCode == 1) {
            if (ok) listen()
            return
        }
        if (ok) {
            toast("Permission দেওয়া হয়েছে ✓")
        } else {
            toast("Permission দেওয়া হয়নি। ফোন সেটিংস থেকে চালু করুন।")
            openAppSettings()
        }
    }

    // ---------- Voice ----------
    override fun onInit(s: Int) { /* TextToSpeech ready */ }

    private fun speak(text: String) {
        tts?.language = Locale.forLanguageTag(voiceTag)
        tts?.speak(text.replace(Regex("```[\\s\\S]*?```"), " "), TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    private fun listen() {
        if (!granted(micPerms)) {
            requestPermissions(micPerms, 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("এই ফোনে Speech recognition পাওয়া যায়নি")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "শুনছি..." }
            override fun onResults(b: Bundle?) {
                status.text = ""
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) {
                    speakReplies = true
                    send(t)
                }
            }
            override fun onError(e: Int) { status.text = ""; toast("শুনতে পারিনি (কোড $e)") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceTag)
        r.startListening(i)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
