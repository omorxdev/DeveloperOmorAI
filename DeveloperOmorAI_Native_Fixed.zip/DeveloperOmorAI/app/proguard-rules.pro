# Keep everything for now (no minify)
-keep class com.omor.developeromorai.** { *; }
